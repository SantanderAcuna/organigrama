# Organigrama Medellín — Full-Stack App

> **Laravel 12 API** + **Vue 3 + TypeScript** CRUD  
> Gestión completa de la Estructura Administrativa del Distrito de Medellín

---

## Estructura del proyecto

```
organigrama/
├── laravel/                    ← API REST (Laravel 12)
│   ├── migrations/
│   │   └── ..._create_organigrama_entities_table.php
│   ├── app/
│   │   ├── Enums/EntityType.php
│   │   ├── Models/OrganigramaEntity.php
│   │   ├── Http/
│   │   │   ├── Controllers/Api/OrganigramaEntityController.php
│   │   │   └── Resources/OrganigramaEntityResource.php
│   ├── routes/api.php
│   ├── config/cors.php
│   ├── database/
│   │   ├── factories/OrganigramaEntityFactory.php
│   │   └── seeders/OrganigramaSeeder.php
│   └── tests/Feature/OrganigramaEntityTest.php
│
└── vue/                        ← Cliente Vue 3 + TypeScript
    └── src/
        ├── types/organigrama.ts
        ├── services/
        │   ├── api.ts
        │   └── organigramaService.ts
        ├── composables/useOrganigrama.ts
        ├── components/
        │   ├── EntityForm.vue
        │   ├── EntityTable.vue
        │   ├── FilterBar.vue
        │   └── ConfirmDialog.vue
        ├── views/OrganigramaView.vue
        ├── router/index.ts
        └── App.vue
```

---

## ⚙️ Setup Laravel 12 (API)

### 1. Crear proyecto Laravel 12

```bash
composer create-project laravel/laravel organigrama-api "^12.0"
cd organigrama-api
```

### 2. Copiar archivos del proyecto

Copia los archivos de la carpeta `laravel/` a sus rutas correspondientes en tu proyecto Laravel:

| Archivo fuente | Destino en Laravel |
|---|---|
| `migrations/*.php` | `database/migrations/` |
| `app/Enums/EntityType.php` | `app/Enums/` |
| `app/Models/OrganigramaEntity.php` | `app/Models/` |
| `app/Http/Controllers/Api/OrganigramaEntityController.php` | `app/Http/Controllers/Api/` |
| `app/Http/Resources/OrganigramaEntityResource.php` | `app/Http/Resources/` |
| `routes/api.php` | `routes/api.php` *(reemplazar)* |
| `config/cors.php` | `config/cors.php` *(reemplazar)* |
| `database/seeders/OrganigramaSeeder.php` | `database/seeders/` |
| `database/factories/OrganigramaEntityFactory.php` | `database/factories/` |
| `tests/Feature/OrganigramaEntityTest.php` | `tests/Feature/` |

### 3. Configurar entorno

```bash
cp .env.example .env
php artisan key:generate
```

Edita `.env`:

```env
APP_URL=http://localhost:8000
FRONTEND_URL=http://localhost:5173

# Opción rápida con SQLite:
DB_CONNECTION=sqlite
# DB_DATABASE= (se crea automático)

# O con MySQL:
# DB_CONNECTION=mysql
# DB_DATABASE=organigrama_medellin
# DB_USERNAME=root
# DB_PASSWORD=tu_password
```

### 4. Migrar y sembrar datos

```bash
# Con SQLite (crea el archivo automáticamente)
touch database/database.sqlite

# Migración + seed completo
php artisan migrate --seed --seeder=OrganigramaSeeder

# O solo migrar primero
php artisan migrate
php artisan db:seed --class=OrganigramaSeeder
```

### 5. Levantar servidor

```bash
php artisan serve
# → http://localhost:8000
```

### 6. Ejecutar tests

```bash
php artisan test --filter=OrganigramaEntityTest
```

---

## 🖥️ Setup Vue 3 + TypeScript (Cliente)

### 1. Crear proyecto Vite

```bash
npm create vite@latest organigrama-client -- --template vue-ts
cd organigrama-client
```

### 2. Instalar dependencias

```bash
npm install axios vue-router@4
```

### 3. Copiar archivos

Copia el contenido de `vue/src/` a tu proyecto:

```
src/
├── types/organigrama.ts
├── services/api.ts
├── services/organigramaService.ts
├── composables/useOrganigrama.ts
├── components/EntityForm.vue
├── components/EntityTable.vue
├── components/FilterBar.vue
├── components/ConfirmDialog.vue
├── views/OrganigramaView.vue
├── router/index.ts
├── App.vue
├── main.ts
└── style.css
```

Reemplaza también `vite.config.ts` y `tsconfig.app.json`.

### 4. Configurar entorno

```bash
cp .env.example .env.local
```

`.env.local`:
```env
VITE_API_URL=http://localhost:8000/api
```

### 5. Levantar cliente

```bash
npm run dev
# → http://localhost:5173
```

---

## 📡 Endpoints de la API

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| `GET` | `/api/organigrama` | Listar (paginado) con filtros |
| `GET` | `/api/organigrama?tree=true` | Árbol jerárquico completo |
| `GET` | `/api/organigrama/{id}` | Detalle con hijos |
| `POST` | `/api/organigrama` | Crear entidad |
| `PUT` | `/api/organigrama/{id}` | Actualizar entidad |
| `DELETE` | `/api/organigrama/{id}` | Eliminar (re-parentea hijos) |
| `GET` | `/api/organigrama/types` | Tipos disponibles + colores |
| `PATCH` | `/api/organigrama/reorder` | Reordenar lote |

### Parámetros de filtrado (GET /api/organigrama)

| Parámetro | Tipo | Ejemplo |
|-----------|------|---------|
| `search` | string | `?search=salud` |
| `type` | string | `?type=secretaria` |
| `parent_id` | int\|'null' | `?parent_id=5` o `?parent_id=null` |
| `active_only` | bool | `?active_only=true` |
| `per_page` | int | `?per_page=50` |
| `page` | int | `?page=2` |
| `tree` | bool | `?tree=true` |

### Ejemplo de respuesta (lista)

```json
{
  "data": [
    {
      "id": 1,
      "name": "Alcalde",
      "type": "alcalde",
      "type_label": "Alcalde",
      "type_color": "#7B1D3A",
      "parent_id": null,
      "parent_name": null,
      "order": 0,
      "active": true,
      "description": null,
      "children_count": 35,
      "created_at": "2024-01-01T00:00:00.000Z",
      "updated_at": "2024-01-01T00:00:00.000Z"
    }
  ],
  "meta": {
    "current_page": 1,
    "last_page": 5,
    "per_page": 20,
    "total": 98,
    "from": 1,
    "to": 20
  }
}
```

### Payload para crear / actualizar

```json
{
  "name":        "Secretaría de Educación",
  "type":        "secretaria",
  "parent_id":   1,
  "order":       5,
  "active":      true,
  "description": "Descripción opcional"
}
```

---

## 🎨 Tipos de entidad y colores

| Valor | Etiqueta | Color |
|-------|----------|-------|
| `alcalde` | Alcalde | `#7B1D3A` |
| `secretaria` | Secretaría / Depto. Administrativo | `#E07850` |
| `gerencia` | Gerencia | `#7B4FA6` |
| `unidad_especial` | Unidad Administrativa Especial | `#E8A0A0` |
| `subsecretaria` | Subsecretaría / Subdirección | `#A0A0A0` |
| `direccion` | Dirección | `#2E7D72` |
| `comisaria` | Comisaría de Familia | `#4BBDC7` |
| `adscrito` | Ente Descentralizado Adscrito | `#F0A030` |
| `vinculado` | Ente Descentralizado Vinculado | `#4A82BF` |
| `indirecto` | Ente Descentralizado Indirecto | `#5CB860` |

---

## 🧱 Funcionalidades del cliente Vue

- ✅ **Listado paginado** con tabla interactiva
- ✅ **Búsqueda** en tiempo real (debounce 350ms)
- ✅ **Filtros** por tipo, estado, paginación configurable
- ✅ **Crear entidad** — formulario modal con validación
- ✅ **Editar entidad** — carga datos existentes automáticamente
- ✅ **Eliminar** con confirmación y re-parenteo de hijos
- ✅ **Toast notifications** de éxito / error
- ✅ **Loading skeletons** animados
- ✅ **TypeScript** completo: tipos, servicios, composables
- ✅ **Composable `useOrganigrama`** — estado centralizado y reutilizable

---

## 💡 Notas de arquitectura

- **Re-parenteo automático**: al borrar una entidad, sus hijos suben un nivel (se asignan al abuelo), preservando la jerarquía.
- **Soft Deletes**: los registros no se eliminan físicamente de la BD.
- **Enum tipado**: `EntityType` en PHP y TypeScript mantienen los tipos sincronizados.
- **API Resource**: respuesta consistente con `type_label` y `type_color` listos para el frontend.
- **Tree mode**: `GET /api/organigrama?tree=true` devuelve el árbol completo anidado recursivamente.
