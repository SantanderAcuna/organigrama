<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrganigramaEntityResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'          => $this->id,
            'name'        => $this->name,
            'type'        => $this->type->value,
            'type_label'  => $this->type->label(),
            'type_color'  => $this->type->color(),
            'parent_id'   => $this->parent_id,
            'parent_name' => $this->whenLoaded('parent', fn () => $this->parent?->name),
            'order'       => $this->order,
            'active'      => $this->active,
            'description' => $this->description,
            'children'    => OrganigramaEntityResource::collection(
                $this->whenLoaded('children')
            ),
            'children_count' => $this->when(
                !$request->routeIs('organigrama.show'),
                fn () => $this->children_count ?? 0
            ),
            'created_at'  => $this->created_at?->toISOString(),
            'updated_at'  => $this->updated_at?->toISOString(),
        ];
    }
}
