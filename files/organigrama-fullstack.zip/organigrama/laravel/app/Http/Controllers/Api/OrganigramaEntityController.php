<?php

namespace App\Http\Controllers\Api;

use App\Enums\EntityType;
use App\Http\Controllers\Controller;
use App\Http\Resources\OrganigramaEntityResource;
use App\Models\OrganigramaEntity;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrganigramaEntityController extends Controller
{
    // ── GET /api/organigrama ────────────────────────────────
    public function index(Request $request): AnonymousResourceCollection
    {
        $query = OrganigramaEntity::withCount('children')
            ->with('parent');

        // Filters
        if ($request->filled('type')) {
            $query->ofType($request->string('type')->toString());
        }

        if ($request->filled('parent_id')) {
            $value = $request->input('parent_id');
            $query->where('parent_id', $value === 'null' ? null : $value);
        }

        if ($request->filled('search')) {
            $query->where('name', 'like', "%{$request->search}%");
        }

        if ($request->boolean('active_only')) {
            $query->active();
        }

        // Tree mode: return full nested tree from roots
        if ($request->boolean('tree')) {
            $roots = OrganigramaEntity::roots()
                ->with('allChildren')
                ->orderBy('order')
                ->orderBy('name')
                ->get();

            return OrganigramaEntityResource::collection($roots);
        }

        $entities = $query
            ->orderBy('order')
            ->orderBy('name')
            ->paginate($request->integer('per_page', 20));

        return OrganigramaEntityResource::collection($entities);
    }

    // ── POST /api/organigrama ───────────────────────────────
    public function store(Request $request): OrganigramaEntityResource
    {
        $data = $request->validate([
            'name'        => ['required', 'string', 'max:255'],
            'type'        => ['required', Rule::enum(EntityType::class)],
            'parent_id'   => ['nullable', 'integer', 'exists:organigrama_entities,id'],
            'order'       => ['nullable', 'integer', 'min:0'],
            'active'      => ['nullable', 'boolean'],
            'description' => ['nullable', 'string', 'max:1000'],
        ]);

        $entity = OrganigramaEntity::create($data);
        $entity->load('parent');

        return new OrganigramaEntityResource($entity);
    }

    // ── GET /api/organigrama/{id} ───────────────────────────
    public function show(OrganigramaEntity $organigrama): OrganigramaEntityResource
    {
        $organigrama->load(['parent', 'children' => fn ($q) => $q->orderBy('order')]);
        return new OrganigramaEntityResource($organigrama);
    }

    // ── PUT /api/organigrama/{id} ───────────────────────────
    public function update(Request $request, OrganigramaEntity $organigrama): OrganigramaEntityResource
    {
        $data = $request->validate([
            'name'        => ['sometimes', 'required', 'string', 'max:255'],
            'type'        => ['sometimes', 'required', Rule::enum(EntityType::class)],
            'parent_id'   => [
                'nullable', 'integer',
                Rule::exists('organigrama_entities', 'id')
                    ->whereNot('id', $organigrama->id), // can't be its own parent
            ],
            'order'       => ['nullable', 'integer', 'min:0'],
            'active'      => ['nullable', 'boolean'],
            'description' => ['nullable', 'string', 'max:1000'],
        ]);

        $organigrama->update($data);
        $organigrama->load(['parent', 'children']);

        return new OrganigramaEntityResource($organigrama);
    }

    // ── DELETE /api/organigrama/{id} ────────────────────────
    public function destroy(OrganigramaEntity $organigrama): JsonResponse
    {
        // Re-parent children to grandfather before deleting
        DB::transaction(function () use ($organigrama) {
            $organigrama->children()->update(['parent_id' => $organigrama->parent_id]);
            $organigrama->delete();
        });

        return response()->json(['message' => 'Entidad eliminada correctamente.']);
    }

    // ── GET /api/organigrama/types ──────────────────────────
    public function types(): JsonResponse
    {
        $types = collect(EntityType::cases())->map(fn (EntityType $e) => [
            'value' => $e->value,
            'label' => $e->label(),
            'color' => $e->color(),
        ]);

        return response()->json(['data' => $types]);
    }

    // ── PATCH /api/organigrama/reorder ──────────────────────
    public function reorder(Request $request): JsonResponse
    {
        $request->validate([
            'items'          => ['required', 'array'],
            'items.*.id'     => ['required', 'integer', 'exists:organigrama_entities,id'],
            'items.*.order'  => ['required', 'integer', 'min:0'],
        ]);

        DB::transaction(function () use ($request) {
            foreach ($request->input('items') as $item) {
                OrganigramaEntity::where('id', $item['id'])
                    ->update(['order' => $item['order']]);
            }
        });

        return response()->json(['message' => 'Orden actualizado.']);
    }
}
