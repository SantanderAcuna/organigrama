<?php

namespace App\Enums;

enum EntityType: string
{
    case Alcalde        = 'alcalde';
    case Secretaria     = 'secretaria';
    case Gerencia       = 'gerencia';
    case UnidadEspecial = 'unidad_especial';
    case Subsecretaria  = 'subsecretaria';
    case Direccion      = 'direccion';
    case Comisaria      = 'comisaria';
    case Adscrito       = 'adscrito';
    case Vinculado      = 'vinculado';
    case Indirecto      = 'indirecto';

    public function label(): string
    {
        return match($this) {
            self::Alcalde        => 'Alcalde',
            self::Secretaria     => 'Secretaría / Depto. Administrativo',
            self::Gerencia       => 'Gerencia',
            self::UnidadEspecial => 'Unidad Administrativa Especial',
            self::Subsecretaria  => 'Subsecretaría / Subdirección',
            self::Direccion      => 'Dirección',
            self::Comisaria      => 'Comisaría de Familia',
            self::Adscrito       => 'Ente Descentralizado Adscrito',
            self::Vinculado      => 'Ente Descentralizado Vinculado',
            self::Indirecto      => 'Ente Descentralizado Indirecto',
        };
    }

    public function color(): string
    {
        return match($this) {
            self::Alcalde        => '#7B1D3A',
            self::Secretaria     => '#E07850',
            self::Gerencia       => '#7B4FA6',
            self::UnidadEspecial => '#E8A0A0',
            self::Subsecretaria  => '#A0A0A0',
            self::Direccion      => '#2E7D72',
            self::Comisaria      => '#4BBDC7',
            self::Adscrito       => '#F0A030',
            self::Vinculado      => '#4A82BF',
            self::Indirecto      => '#5CB860',
        };
    }

    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }
}
