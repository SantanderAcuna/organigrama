<?php

namespace App\Models;

use App\Enums\EntityType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OrganigramaEntity extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'organigrama_entities';

    protected $fillable = [
        'name',
        'type',
        'parent_id',
        'order',
        'active',
        'description',
    ];

    protected $casts = [
        'type'   => EntityType::class,
        'active' => 'boolean',
        'order'  => 'integer',
    ];

    // ── Relationships ──────────────────────────────────────

    public function parent(): BelongsTo
    {
        return $this->belongsTo(OrganigramaEntity::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(OrganigramaEntity::class, 'parent_id')
                    ->orderBy('order')
                    ->orderBy('name');
    }

    public function allChildren(): HasMany
    {
        return $this->children()->with('allChildren');
    }

    // ── Scopes ─────────────────────────────────────────────

    public function scopeRoots($query)
    {
        return $query->whereNull('parent_id');
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    public function scopeOfType($query, string|array $type)
    {
        return $query->whereIn('type', (array) $type);
    }
}
