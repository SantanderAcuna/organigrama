<?php

use App\Http\Controllers\Api\OrganigramaEntityController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes  (routes/api.php)
|--------------------------------------------------------------------------
| Prefix: /api   (set in bootstrap/app.php → withRouting)
|--------------------------------------------------------------------------
*/

Route::prefix('organigrama')->name('organigrama.')->group(function () {

    // Meta: available types + colors
    Route::get('types',   [OrganigramaEntityController::class, 'types'])  ->name('types');

    // Reorder batch
    Route::patch('reorder', [OrganigramaEntityController::class, 'reorder'])->name('reorder');

    // Standard CRUD
    Route::apiResource('/', OrganigramaEntityController::class)
         ->parameters(['' => 'organigrama'])
         ->names([
             'index'   => 'index',
             'store'   => 'store',
             'show'    => 'show',
             'update'  => 'update',
             'destroy' => 'destroy',
         ]);
});

/*
| Endpoints generated:
|
|  GET     /api/organigrama/types          → types()
|  PATCH   /api/organigrama/reorder        → reorder()
|  GET     /api/organigrama                → index()   ?tree=1 | ?type= | ?search= | ?parent_id=
|  POST    /api/organigrama                → store()
|  GET     /api/organigrama/{id}           → show()
|  PUT     /api/organigrama/{id}           → update()
|  DELETE  /api/organigrama/{id}           → destroy()
*/
