<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('organigrama_entities', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->enum('type', [
                'alcalde',
                'secretaria',
                'gerencia',
                'unidad_especial',
                'subsecretaria',
                'direccion',
                'comisaria',
                'adscrito',
                'vinculado',
                'indirecto',
            ]);
            $table->foreignId('parent_id')
                  ->nullable()
                  ->constrained('organigrama_entities')
                  ->nullOnDelete();
            $table->unsignedInteger('order')->default(0);
            $table->boolean('active')->default(true);
            $table->text('description')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('organigrama_entities');
    }
};
