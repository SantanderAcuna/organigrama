<?php

// config/cors.php
return [

    /*
    |----------------------------------------------------------------------
    | Laravel CORS Configuration
    |----------------------------------------------------------------------
    | Permite que el cliente Vue (http://localhost:5173) acceda a la API.
    | En producción, reemplaza los valores con los dominios reales.
    */

    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        env('FRONTEND_URL', 'http://localhost:5173'),
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => true,
];
