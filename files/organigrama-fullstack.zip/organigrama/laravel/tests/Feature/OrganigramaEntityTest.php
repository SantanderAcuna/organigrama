<?php

namespace Tests\Feature;

use App\Enums\EntityType;
use App\Models\OrganigramaEntity;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OrganigramaEntityTest extends TestCase
{
    use RefreshDatabase;

    // ── Index ──────────────────────────────────────────────────
    public function test_can_list_entities(): void
    {
        OrganigramaEntity::factory()->count(5)->create();

        $this->getJson('/api/organigrama')
             ->assertOk()
             ->assertJsonStructure([
                 'data'  => [['id', 'name', 'type', 'type_label', 'type_color']],
                 'meta'  => ['total', 'current_page'],
             ]);
    }

    public function test_can_filter_by_type(): void
    {
        OrganigramaEntity::factory()->secretaria()->count(3)->create();
        OrganigramaEntity::factory()->gerencia()->count(2)->create();

        $res = $this->getJson('/api/organigrama?type=secretaria')
                    ->assertOk();

        $this->assertCount(3, $res->json('data'));
    }

    public function test_can_fetch_tree(): void
    {
        $root  = OrganigramaEntity::factory()->create(['parent_id' => null]);
        OrganigramaEntity::factory()->count(3)->withParent($root->id)->create();

        $res = $this->getJson('/api/organigrama?tree=true')->assertOk();
        $this->assertTrue(count($res->json('data')) > 0);
    }

    // ── Store ──────────────────────────────────────────────────
    public function test_can_create_entity(): void
    {
        $payload = [
            'name'  => 'Secretaría de Prueba',
            'type'  => 'secretaria',
            'order' => 5,
        ];

        $this->postJson('/api/organigrama', $payload)
             ->assertCreated()
             ->assertJsonPath('data.name', 'Secretaría de Prueba')
             ->assertJsonPath('data.type', 'secretaria');

        $this->assertDatabaseHas('organigrama_entities', ['name' => 'Secretaría de Prueba']);
    }

    public function test_create_requires_name_and_type(): void
    {
        $this->postJson('/api/organigrama', [])
             ->assertUnprocessable()
             ->assertJsonValidationErrors(['name', 'type']);
    }

    public function test_create_rejects_invalid_type(): void
    {
        $this->postJson('/api/organigrama', ['name' => 'X', 'type' => 'invalid_type'])
             ->assertUnprocessable()
             ->assertJsonValidationErrors(['type']);
    }

    // ── Show ───────────────────────────────────────────────────
    public function test_can_show_entity_with_children(): void
    {
        $parent = OrganigramaEntity::factory()->create();
        OrganigramaEntity::factory()->count(2)->withParent($parent->id)->create();

        $this->getJson("/api/organigrama/{$parent->id}")
             ->assertOk()
             ->assertJsonStructure(['data' => ['id', 'name', 'children']]);
    }

    public function test_show_returns_404_for_missing(): void
    {
        $this->getJson('/api/organigrama/9999')->assertNotFound();
    }

    // ── Update ─────────────────────────────────────────────────
    public function test_can_update_entity(): void
    {
        $entity = OrganigramaEntity::factory()->create(['name' => 'Original']);

        $this->putJson("/api/organigrama/{$entity->id}", [
                 'name'  => 'Nombre Actualizado',
                 'type'  => $entity->type->value,
             ])
             ->assertOk()
             ->assertJsonPath('data.name', 'Nombre Actualizado');
    }

    public function test_entity_cannot_be_its_own_parent(): void
    {
        $entity = OrganigramaEntity::factory()->create();

        $this->putJson("/api/organigrama/{$entity->id}", [
                 'name'      => $entity->name,
                 'type'      => $entity->type->value,
                 'parent_id' => $entity->id,
             ])
             ->assertUnprocessable()
             ->assertJsonValidationErrors(['parent_id']);
    }

    // ── Destroy ────────────────────────────────────────────────
    public function test_can_delete_entity_and_reparents_children(): void
    {
        $parent   = OrganigramaEntity::factory()->create(['parent_id' => null]);
        $middle   = OrganigramaEntity::factory()->withParent($parent->id)->create();
        $child    = OrganigramaEntity::factory()->withParent($middle->id)->create();

        $this->deleteJson("/api/organigrama/{$middle->id}")->assertOk();

        $this->assertSoftDeleted('organigrama_entities', ['id' => $middle->id]);
        $this->assertDatabaseHas('organigrama_entities', [
            'id'        => $child->id,
            'parent_id' => $parent->id,   // re-parented to grandfather
        ]);
    }

    // ── Types ──────────────────────────────────────────────────
    public function test_can_fetch_types(): void
    {
        $this->getJson('/api/organigrama/types')
             ->assertOk()
             ->assertJsonStructure(['data' => [['value', 'label', 'color']]]);
    }

    // ── Reorder ────────────────────────────────────────────────
    public function test_can_reorder_entities(): void
    {
        $a = OrganigramaEntity::factory()->create(['order' => 1]);
        $b = OrganigramaEntity::factory()->create(['order' => 2]);

        $this->patchJson('/api/organigrama/reorder', [
                 'items' => [
                     ['id' => $a->id, 'order' => 10],
                     ['id' => $b->id, 'order' => 20],
                 ],
             ])
             ->assertOk();

        $this->assertDatabaseHas('organigrama_entities', ['id' => $a->id, 'order' => 10]);
        $this->assertDatabaseHas('organigrama_entities', ['id' => $b->id, 'order' => 20]);
    }
}
