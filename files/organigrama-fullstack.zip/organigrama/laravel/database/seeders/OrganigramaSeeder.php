<?php

namespace Database\Seeders;

use App\Enums\EntityType;
use App\Models\OrganigramaEntity;
use Illuminate\Database\Seeder;

class OrganigramaSeeder extends Seeder
{
    public function run(): void
    {
        OrganigramaEntity::truncate();

        // ── Helpers ────────────────────────────────────────
        $make = fn (string $name, EntityType $type, ?int $parentId = null, int $order = 0) =>
            OrganigramaEntity::create([
                'name'      => $name,
                'type'      => $type,
                'parent_id' => $parentId,
                'order'     => $order,
                'active'    => true,
            ])->id;

        // ── Alcalde ────────────────────────────────────────
        $alcalde = $make('Alcalde', EntityType::Alcalde);

        // ── Nivel 1 ────────────────────────────────────────
        $gobierno  = $make('Gobierno y Gestión del Gabinete', EntityType::Secretaria, $alcalde, 1);
        $evaluacion = $make('Evaluación y Control',           EntityType::Secretaria, $alcalde, 2);

        // Gobierno → Privada → Comunicaciones
        $privada = $make('Privada',        EntityType::Secretaria, $gobierno, 1);
        $comunic = $make('Comunicaciones', EntityType::Secretaria, $privada,  1);
        $make('Comunicación Estratégica',  EntityType::Subsecretaria, $comunic, 1);

        // Gerencias
        $make('Gerencia de Corregimientos',                          EntityType::Gerencia, $gobierno, 2);
        $make('Gerencia del Centro y Territorios Estratégicos',      EntityType::Gerencia, $gobierno, 3);
        $make('Gerencia de Proyectos Estratégicos',                  EntityType::Gerencia, $gobierno, 4);
        $make('Gerencia Étnica',                                     EntityType::Gerencia, $gobierno, 5);
        $make('Gerencia de Diversidades Sexuales e Identidades de Género', EntityType::Gerencia, $gobierno, 6);

        // Evaluación y Control
        $make('Evaluación y Seguimiento', EntityType::Subsecretaria, $evaluacion, 1);
        $make('Asesoría y Acompañamiento', EntityType::Subsecretaria, $evaluacion, 2);

        // ── Secretarías – Fila 1 ───────────────────────────
        $paz = $make('Paz y Derechos Humanos', EntityType::Secretaria, $alcalde, 10);
        $make('Justicia Transicional y Restaurativa',             EntityType::Subsecretaria, $paz, 1);
        $make('Derechos Humanos y Construcción de Paz Ciudadana', EntityType::Subsecretaria, $paz, 2);

        $general = $make('General', EntityType::Secretaria, $alcalde, 11);
        $make('Prevención del Daño Antijurídico',   EntityType::Subsecretaria, $general, 1);
        $make('Defensa y Protección de lo Público', EntityType::Subsecretaria, $general, 2);

        $gestion = $make('Gestión Humana y Servicio a la Ciudadanía', EntityType::Secretaria, $alcalde, 12);
        $make('Gestión Humana',                        EntityType::Subsecretaria, $gestion, 1);
        $make('Servicio a la Ciudadanía',              EntityType::Subsecretaria, $gestion, 2);
        $make('Desarrollo Institucional',              EntityType::Subsecretaria, $gestion, 3);
        $make('Dirección de Control Disciplinario Interno', EntityType::Direccion, $gestion, 4);

        $suministros = $make('Suministros y Servicios', EntityType::Secretaria, $alcalde, 13);
        $make('Planeación y Evaluación',               EntityType::Subsecretaria, $suministros, 1);
        $make('Selección y Gestión de Proveedores',    EntityType::Subsecretaria, $suministros, 2);
        $make('Ejecución de la Contratación',          EntityType::Subsecretaria, $suministros, 3);
        $make('Gestión de Bienes',                     EntityType::Subsecretaria, $suministros, 4);

        $edu = $make('Educación', EntityType::Secretaria, $alcalde, 14);
        $make('Administrativa y Financiera',  EntityType::Subsecretaria, $edu, 1);
        $make('Planeación Educativa',         EntityType::Subsecretaria, $edu, 2);
        $make('Prestación del Servicio Educativo', EntityType::Subsecretaria, $edu, 3);
        $bienComienzo = $make('Unidad Administrativa Especial Buen Comienzo', EntityType::UnidadEspecial, $edu, 4);
        $make('Nutrición',            EntityType::Subsecretaria, $bienComienzo, 1);
        $make('Prestación del Servicio', EntityType::Subsecretaria, $bienComienzo, 2);

        $part = $make('Participación Ciudadana', EntityType::Secretaria, $alcalde, 15);
        $make('Formación y Participación Ciudadana',       EntityType::Subsecretaria, $part, 1);
        $make('Organización Social',                       EntityType::Subsecretaria, $part, 2);
        $make('Planeación Local y Presupuesto Participativo', EntityType::Subsecretaria, $part, 3);

        $cultura = $make('Cultura Ciudadana', EntityType::Secretaria, $alcalde, 16);
        $make('Ciudadanía Cultural',            EntityType::Subsecretaria, $cultura, 1);
        $make('Arte y Cultura',                 EntityType::Subsecretaria, $cultura, 2);
        $make('Biblioteca, Lectura y Patrimonio', EntityType::Subsecretaria, $cultura, 3);

        $salud = $make('Salud', EntityType::Secretaria, $alcalde, 17);
        $make('Gestión de Servicios de Salud', EntityType::Subsecretaria, $salud, 1);
        $make('Salud Pública',                 EntityType::Subsecretaria, $salud, 2);
        $make('Administrativa y Financiera',   EntityType::Subsecretaria, $salud, 3);

        $inclusion = $make('Inclusión Social y Familia', EntityType::Secretaria, $alcalde, 18);
        $make('Grupos Poblacionales',         EntityType::Subsecretaria, $inclusion, 1);
        $make('Técnica de Inclusión Social',  EntityType::Subsecretaria, $inclusion, 2);

        $mujeres = $make('Mujeres', EntityType::Secretaria, $alcalde, 19);
        $make('Derechos',          EntityType::Subsecretaria, $mujeres, 1);
        $make('Transversalización', EntityType::Subsecretaria, $mujeres, 2);

        $make('Juventud', EntityType::Secretaria, $alcalde, 20);

        // ── Secretarías – Fila 2 ───────────────────────────
        $turismo = $make('Turismo y Entretenimiento', EntityType::Secretaria, $alcalde, 21);
        $make('Planificación, Control y Competitividad Turística', EntityType::Subsecretaria, $turismo, 1);
        $make('Promoción Turística y Entretenimiento',             EntityType::Subsecretaria, $turismo, 2);

        $hacienda = $make('Hacienda', EntityType::Secretaria, $alcalde, 22);
        $make('Ingresos',                    EntityType::Subsecretaria, $hacienda, 1);
        $make('Tesorería',                   EntityType::Subsecretaria, $hacienda, 2);
        $make('Presupuesto y Gestión Financiera', EntityType::Subsecretaria, $hacienda, 3);
        $make('Fonvalmed', EntityType::Adscrito, $hacienda, 4);
        $make('APEV',      EntityType::Adscrito, $hacienda, 5);

        $seguridad = $make('Seguridad y Convivencia', EntityType::Secretaria, $alcalde, 23);
        $make('Planeación de la Seguridad',  EntityType::Subsecretaria, $seguridad, 1);
        $make('Operativa de la Seguridad',   EntityType::Subsecretaria, $seguridad, 2);
        $make('Espacio Público',             EntityType::Subsecretaria, $seguridad, 3);
        $make('Gobierno Local y Convivencia', EntityType::Subsecretaria, $seguridad, 4);
        $make('Comisarías de Familia',       EntityType::Comisaria, $seguridad, 5);

        $riesgo = $make('Departamento Administrativo de Gestión del Riesgo de Desastres', EntityType::Secretaria, $alcalde, 24);
        $make('Conocimiento y Reducción del Riesgo', EntityType::Subsecretaria, $riesgo, 1);
        $make('Manejo de Desastres',                 EntityType::Subsecretaria, $riesgo, 2);

        $infra = $make('Infraestructura Física', EntityType::Secretaria, $alcalde, 25);
        $make('Planeación',                EntityType::Subsecretaria, $infra, 1);
        $make('Construcción y Mantenimiento', EntityType::Subsecretaria, $infra, 2);

        $ambiente = $make('Medio Ambiente', EntityType::Secretaria, $alcalde, 26);
        $make('Gestión Ambiental',              EntityType::Subsecretaria, $ambiente, 1);
        $make('Recursos Naturales Renovables',  EntityType::Subsecretaria, $ambiente, 2);
        $make('Protección y Bienestar Animal',  EntityType::Subsecretaria, $ambiente, 3);

        $movilidad = $make('Movilidad', EntityType::Secretaria, $alcalde, 27);
        $make('Seguridad Vial y Control', EntityType::Subsecretaria, $movilidad, 1);
        $make('Legal',                    EntityType::Subsecretaria, $movilidad, 2);
        $make('Técnica',                  EntityType::Subsecretaria, $movilidad, 3);
        $make('Gerencia de Movilidad Humana', EntityType::Gerencia, $movilidad, 4);

        $desarrollo = $make('Desarrollo Económico', EntityType::Secretaria, $alcalde, 28);
        $make('Desarrollo Rural',                    EntityType::Subsecretaria, $desarrollo, 1);
        $make('Creación y Fortalecimiento Empresarial', EntityType::Subsecretaria, $desarrollo, 2);

        $digital = $make('Innovación Digital', EntityType::Secretaria, $alcalde, 29);
        $make('Servicios de Tecnología de la Información', EntityType::Subsecretaria, $digital, 1);
        $make('Ciudad Inteligente',                        EntityType::Subsecretaria, $digital, 2);

        $planeacion = $make('Departamento Administrativo de Planeación', EntityType::Secretaria, $alcalde, 30);
        $make('Planeación Social y Económica',                EntityType::Subsecretaria, $planeacion, 1);
        $make('Prospectiva, Información y Evaluación Estratégica', EntityType::Subsecretaria, $planeacion, 2);
        $make('Planeación Territorial y Estrategia de Ciudad', EntityType::Subsecretaria, $planeacion, 3);

        $territorial = $make('Gestión y Control Territorial', EntityType::Secretaria, $alcalde, 31);
        $make('Control Urbanístico', EntityType::Subsecretaria, $territorial, 1);
        $make('Catastro',            EntityType::Subsecretaria, $territorial, 2);
        $make('Servicios Públicos',  EntityType::Subsecretaria, $territorial, 3);

        // ── Entes Descentralizados Adscritos ───────────────
        foreach ([
            'Colegio Mayor de Antioquia', 'I.U. Pascual Bravo', 'ITM', 'Inder',
            'Biblioteca Pública Piloto', 'Museo Casa de la Memoria', 'Sapiencia',
            'Hospital General', 'Metrosalud', 'Isvimed',
            'Aeropuerto Olaya Herrera', 'Agencia APP',
        ] as $i => $name) {
            $make($name, EntityType::Adscrito, $alcalde, 40 + $i);
        }

        // ── Entes Descentralizados Vinculados ──────────────
        foreach ([
            'Metroparques', 'ESU', 'EDU', 'Metro', 'EPM',
            'Savia Salud', 'Plaza Mayor', 'Metroplus', 'Terminales',
        ] as $i => $name) {
            $make($name, EntityType::Vinculado, $alcalde, 60 + $i);
        }

        // ── Entes Descentralizados Indirectos ──────────────
        foreach ([
            'Ferrocarril de Antioquia', 'Parque Explora',
            'Corp. Hospital Infantil Concejo de Medellín', 'Corp. Cuenca Verde',
            'Corp. Parque Arví', 'Fund. Jardín Botánico', 'ACI', 'Ruta N',
            'Telemedellin', 'Créame', 'Teleantioquia', 'Fondo de Garantías', 'Bureau',
        ] as $i => $name) {
            $make($name, EntityType::Indirecto, $alcalde, 80 + $i);
        }

        $this->command->info('✅ Organigrama sembrado correctamente.');
    }
}
