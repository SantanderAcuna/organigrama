<?php

namespace Database\Factories;

use App\Enums\EntityType;
use App\Models\OrganigramaEntity;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrganigramaEntityFactory extends Factory
{
    protected $model = OrganigramaEntity::class;

    public function definition(): array
    {
        return [
            'name'        => $this->faker->words(3, true),
            'type'        => $this->faker->randomElement(EntityType::values()),
            'parent_id'   => null,
            'order'       => $this->faker->numberBetween(0, 100),
            'active'      => $this->faker->boolean(85),
            'description' => $this->faker->optional()->sentence(),
        ];
    }

    public function secretaria(): static
    {
        return $this->state(['type' => EntityType::Secretaria->value]);
    }

    public function gerencia(): static
    {
        return $this->state(['type' => EntityType::Gerencia->value]);
    }

    public function withParent(int $parentId): static
    {
        return $this->state(['parent_id' => $parentId]);
    }

    public function inactive(): static
    {
        return $this->state(['active' => false]);
    }
}
