// ─────────────────────────────────────────────────────────────
// main.ts
// ─────────────────────────────────────────────────────────────
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './style.css' // global reset / base styles

const app = createApp(App)
app.use(router)
app.mount('#app')
