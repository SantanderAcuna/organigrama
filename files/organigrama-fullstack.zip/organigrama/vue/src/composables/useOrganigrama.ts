// ─────────────────────────────────────────────────────────────
// composables/useOrganigrama.ts
// ─────────────────────────────────────────────────────────────
import { ref, reactive, computed } from 'vue'
import { organigramaService } from '@/services/organigramaService'
import type {
  OrganigramaEntity,
  EntityFilters,
  CreateEntityPayload,
  UpdateEntityPayload,
  EntityType,
} from '@/types/organigrama'

export function useOrganigrama() {
  // ── State ───────────────────────────────────────────────────
  const entities    = ref<OrganigramaEntity[]>([])
  const selected    = ref<OrganigramaEntity | null>(null)
  const entityTypes = ref<EntityType[]>([])
  const loading     = ref(false)
  const error       = ref<string | null>(null)

  const pagination = reactive({
    currentPage: 1,
    lastPage:    1,
    perPage:     20,
    total:       0,
  })

  const filters = reactive<EntityFilters>({
    search:      '',
    type:        '',
    parent_id:   '',
    active_only: false,
    per_page:    20,
    page:        1,
  })

  // ── Computed ────────────────────────────────────────────────
  const typeMap = computed(() =>
    Object.fromEntries(entityTypes.value.map((t) => [t.value, t]))
  )

  // ── Helpers ─────────────────────────────────────────────────
  function setError(e: unknown) {
    error.value = e instanceof Error ? e.message : 'Error inesperado'
  }

  // ── Actions ─────────────────────────────────────────────────
  async function fetchEntities() {
    loading.value = true
    error.value   = null
    try {
      const res = await organigramaService.list(filters)
      entities.value = res.data.data
      pagination.currentPage = res.data.meta.current_page
      pagination.lastPage    = res.data.meta.last_page
      pagination.perPage     = res.data.meta.per_page
      pagination.total       = res.data.meta.total
    } catch (e) {
      setError(e)
    } finally {
      loading.value = false
    }
  }

  async function fetchTree() {
    loading.value = true
    error.value   = null
    try {
      const res = await organigramaService.tree()
      entities.value = res.data.data
    } catch (e) {
      setError(e)
    } finally {
      loading.value = false
    }
  }

  async function fetchOne(id: number) {
    loading.value = true
    error.value   = null
    try {
      const res = await organigramaService.get(id)
      selected.value = res.data.data
      return res.data.data
    } catch (e) {
      setError(e)
      return null
    } finally {
      loading.value = false
    }
  }

  async function createEntity(payload: CreateEntityPayload): Promise<OrganigramaEntity | null> {
    loading.value = true
    error.value   = null
    try {
      const res = await organigramaService.create(payload)
      await fetchEntities()
      return res.data.data
    } catch (e) {
      setError(e)
      return null
    } finally {
      loading.value = false
    }
  }

  async function updateEntity(id: number, payload: UpdateEntityPayload): Promise<OrganigramaEntity | null> {
    loading.value = true
    error.value   = null
    try {
      const res = await organigramaService.update(id, payload)
      // Update in-place
      const idx = entities.value.findIndex((e) => e.id === id)
      if (idx !== -1) entities.value[idx] = res.data.data
      if (selected.value?.id === id) selected.value = res.data.data
      return res.data.data
    } catch (e) {
      setError(e)
      return null
    } finally {
      loading.value = false
    }
  }

  async function deleteEntity(id: number): Promise<boolean> {
    loading.value = true
    error.value   = null
    try {
      await organigramaService.remove(id)
      entities.value = entities.value.filter((e) => e.id !== id)
      if (selected.value?.id === id) selected.value = null
      pagination.total--
      return true
    } catch (e) {
      setError(e)
      return false
    } finally {
      loading.value = false
    }
  }

  async function fetchTypes() {
    try {
      const res = await organigramaService.types()
      entityTypes.value = res.data.data
    } catch (e) {
      setError(e)
    }
  }

  function setPage(page: number) {
    filters.page = page
    fetchEntities()
  }

  function resetFilters() {
    Object.assign(filters, {
      search: '', type: '', parent_id: '',
      active_only: false, per_page: 20, page: 1,
    })
    fetchEntities()
  }

  return {
    // state
    entities, selected, entityTypes, loading, error, pagination, filters,
    // computed
    typeMap,
    // actions
    fetchEntities, fetchTree, fetchOne,
    createEntity, updateEntity, deleteEntity,
    fetchTypes, setPage, resetFilters,
  }
}
