<script setup lang="ts">
// ─────────────────────────────────────────────────────────────
// views/OrganigramaView.vue  – Main CRUD page
// ─────────────────────────────────────────────────────────────
import { ref, onMounted, watch } from 'vue'
import { useOrganigrama } from '@/composables/useOrganigrama'
import EntityTable    from '@/components/EntityTable.vue'
import EntityForm     from '@/components/EntityForm.vue'
import FilterBar      from '@/components/FilterBar.vue'
import ConfirmDialog  from '@/components/ConfirmDialog.vue'
import type { OrganigramaEntity, CreateEntityPayload } from '@/types/organigrama'

// ── Composable ───────────────────────────────────────────────
const {
  entities, entityTypes, loading, error, pagination, filters,
  fetchEntities, fetchTypes, createEntity, updateEntity, deleteEntity,
  setPage, resetFilters,
} = useOrganigrama()

// ── Modal state ──────────────────────────────────────────────
const showForm    = ref(false)
const showConfirm = ref(false)
const editTarget  = ref<OrganigramaEntity | null>(null)
const deleteTarget = ref<OrganigramaEntity | null>(null)

// Toast notification
const toast = ref<{ msg: string; type: 'ok' | 'err' } | null>(null)
function showToast(msg: string, type: 'ok' | 'err' = 'ok') {
  toast.value = { msg, type }
  setTimeout(() => (toast.value = null), 3500)
}

// ── Handlers ─────────────────────────────────────────────────
function openCreate() {
  editTarget.value = null
  showForm.value = true
}

function openEdit(entity: OrganigramaEntity) {
  editTarget.value = entity
  showForm.value = true
}

function openDelete(entity: OrganigramaEntity) {
  deleteTarget.value = entity
  showConfirm.value = true
}

async function handleSubmit(payload: CreateEntityPayload, id?: number) {
  if (id) {
    const res = await updateEntity(id, payload)
    if (res) showToast(`"${res.name}" actualizado correctamente.`)
    else showToast(error.value ?? 'Error al actualizar.', 'err')
  } else {
    const res = await createEntity(payload)
    if (res) showToast(`"${res.name}" creado correctamente.`)
    else showToast(error.value ?? 'Error al crear.', 'err')
  }
}

async function handleDelete() {
  if (!deleteTarget.value) return
  const name = deleteTarget.value.name
  const ok = await deleteEntity(deleteTarget.value.id)
  if (ok) showToast(`"${name}" eliminado.`)
  else showToast(error.value ?? 'Error al eliminar.', 'err')
  deleteTarget.value = null
}

// ── Watch search debounce ─────────────────────────────────────
let debounceTimer: ReturnType<typeof setTimeout>
watch(() => filters.search, () => {
  clearTimeout(debounceTimer)
  debounceTimer = setTimeout(() => {
    filters.page = 1
    fetchEntities()
  }, 350)
})

// ── Init ─────────────────────────────────────────────────────
onMounted(async () => {
  await fetchTypes()
  await fetchEntities()
})
</script>

<template>
  <div class="ov-page">

    <!-- Header -->
    <div class="ov-header">
      <div>
        <h1 class="ov-title">Estructura Administrativa</h1>
        <p class="ov-subtitle">Distrito de Medellín — Gestión de Entidades</p>
      </div>
      <div class="ov-header-stats">
        <div class="ov-stat">
          <span class="ov-stat-num">{{ pagination.total }}</span>
          <span class="ov-stat-lbl">Entidades</span>
        </div>
        <div class="ov-stat">
          <span class="ov-stat-num">{{ entityTypes.length }}</span>
          <span class="ov-stat-lbl">Tipos</span>
        </div>
      </div>
    </div>

    <!-- Error banner -->
    <div v-if="error" class="ov-error">
      ⚠️ {{ error }}
    </div>

    <!-- Filters -->
    <FilterBar
      :filters="filters"
      :entityTypes="entityTypes"
      @search="fetchEntities"
      @reset="resetFilters"
      @create="openCreate"
    />

    <!-- Table -->
    <EntityTable
      :entities="entities"
      :loading="loading"
      :total="pagination.total"
      :currentPage="pagination.currentPage"
      :lastPage="pagination.lastPage"
      @edit="openEdit"
      @delete="openDelete"
      @page="setPage"
    />

    <!-- Create / Edit Form Modal -->
    <EntityForm
      v-model="showForm"
      :entity="editTarget"
      :entityTypes="entityTypes"
      :parentOptions="entities"
      @submit="handleSubmit"
    />

    <!-- Delete Confirm -->
    <ConfirmDialog
      v-model="showConfirm"
      title="¿Eliminar entidad?"
      :message="`Se eliminará '${deleteTarget?.name}'. Sus dependencias se reasignarán al nivel superior.`"
      confirmLabel="Sí, eliminar"
      :danger="true"
      @confirm="handleDelete"
    />

    <!-- Toast -->
    <Transition name="toast">
      <div
        v-if="toast"
        :class="['ov-toast', toast.type === 'err' ? 'ov-toast--err' : 'ov-toast--ok']"
      >
        {{ toast.type === 'ok' ? '✅' : '❌' }} {{ toast.msg }}
      </div>
    </Transition>

  </div>
</template>

<style scoped>
.ov-page {
  min-height: 100vh;
  background: #f5f7fa;
  padding: 28px 32px;
  font-family: 'Nunito', sans-serif;
}

.ov-header {
  display: flex; justify-content: space-between; align-items: flex-start;
  margin-bottom: 22px;
}
.ov-title {
  font-size: 22px; font-weight: 800; color: #1a1a2e; margin-bottom: 3px;
}
.ov-subtitle { font-size: 13px; color: #888; }

.ov-header-stats { display: flex; gap: 16px; }
.ov-stat {
  background: #fff; border-radius: 10px; border: 1px solid #e5e9f0;
  padding: 10px 18px; text-align: center; min-width: 72px;
}
.ov-stat-num { display: block; font-size: 20px; font-weight: 800; color: #5A9AC5; }
.ov-stat-lbl { font-size: 11px; color: #999; font-weight: 600; }

.ov-error {
  background: #ffebee; color: #c62828;
  padding: 12px 16px; border-radius: 8px;
  font-size: 13px; font-weight: 600;
  margin-bottom: 14px; border: 1px solid #ffcdd2;
}

/* Toast */
.ov-toast {
  position: fixed; bottom: 24px; right: 24px;
  padding: 12px 20px; border-radius: 10px;
  font-size: 13px; font-weight: 600;
  box-shadow: 0 6px 24px rgba(0,0,0,.15);
  z-index: 2000; max-width: 380px;
}
.ov-toast--ok  { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
.ov-toast--err { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }

.toast-enter-active, .toast-leave-active { transition: all .25s; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateY(16px); }
</style>
