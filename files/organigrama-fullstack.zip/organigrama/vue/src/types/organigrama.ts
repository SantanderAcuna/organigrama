// ─────────────────────────────────────────────────────────────
// types/organigrama.ts
// ─────────────────────────────────────────────────────────────

export type EntityTypeValue =
  | 'alcalde'
  | 'secretaria'
  | 'gerencia'
  | 'unidad_especial'
  | 'subsecretaria'
  | 'direccion'
  | 'comisaria'
  | 'adscrito'
  | 'vinculado'
  | 'indirecto'

export interface EntityType {
  value: EntityTypeValue
  label: string
  color: string
}

export interface OrganigramaEntity {
  id: number
  name: string
  type: EntityTypeValue
  type_label: string
  type_color: string
  parent_id: number | null
  parent_name?: string
  order: number
  active: boolean
  description: string | null
  children?: OrganigramaEntity[]
  children_count?: number
  created_at: string
  updated_at: string
}

// ── API payloads ──────────────────────────────────────────────

export interface CreateEntityPayload {
  name: string
  type: EntityTypeValue
  parent_id: number | null
  order?: number
  active?: boolean
  description?: string | null
}

export type UpdateEntityPayload = Partial<CreateEntityPayload>

export interface ReorderItem {
  id: number
  order: number
}

// ── API responses ─────────────────────────────────────────────

export interface PaginatedResponse<T> {
  data: T[]
  meta: {
    current_page: number
    last_page: number
    per_page: number
    total: number
    from: number
    to: number
  }
  links: {
    first: string
    last: string
    prev: string | null
    next: string | null
  }
}

export interface SingleResponse<T> {
  data: T
}

export interface TypesResponse {
  data: EntityType[]
}

export interface MessageResponse {
  message: string
}

// ── Filters ───────────────────────────────────────────────────

export interface EntityFilters {
  search: string
  type: EntityTypeValue | ''
  parent_id: number | 'null' | ''
  active_only: boolean
  per_page: number
  page: number
}
