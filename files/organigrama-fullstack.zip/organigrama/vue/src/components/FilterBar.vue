<script setup lang="ts">
// ─────────────────────────────────────────────────────────────
// components/FilterBar.vue
// ─────────────────────────────────────────────────────────────
import type { EntityFilters, EntityType } from '@/types/organigrama'

defineProps<{
  filters: EntityFilters
  entityTypes: EntityType[]
}>()

const emit = defineEmits<{
  search:  []
  reset:   []
  create:  []
}>()
</script>

<template>
  <div class="fb-bar">
    <!-- Search -->
    <div class="fb-field fb-field--grow">
      <input
        v-model="filters.search"
        class="fb-input"
        type="search"
        placeholder="🔍 Buscar por nombre…"
        @keyup.enter="emit('search')"
      />
    </div>

    <!-- Type filter -->
    <div class="fb-field">
      <select v-model="filters.type" class="fb-input" @change="emit('search')">
        <option value="">Todos los tipos</option>
        <option v-for="t in entityTypes" :key="t.value" :value="t.value">
          {{ t.label }}
        </option>
      </select>
    </div>

    <!-- Active only -->
    <label class="fb-toggle">
      <input v-model="filters.active_only" type="checkbox" @change="emit('search')" />
      <span>Solo activos</span>
    </label>

    <!-- Per page -->
    <div class="fb-field">
      <select v-model="filters.per_page" class="fb-input fb-input--sm" @change="emit('search')">
        <option :value="10">10 / pág</option>
        <option :value="20">20 / pág</option>
        <option :value="50">50 / pág</option>
        <option :value="100">100 / pág</option>
      </select>
    </div>

    <!-- Buttons -->
    <button class="fb-btn fb-btn--ghost" @click="emit('reset')">↺ Limpiar</button>
    <button class="fb-btn fb-btn--primary" @click="emit('search')">Buscar</button>
    <button class="fb-btn fb-btn--create" @click="emit('create')">+ Nueva Entidad</button>
  </div>
</template>

<style scoped>
.fb-bar {
  display: flex; flex-wrap: wrap; align-items: center;
  gap: 10px; padding: 14px 16px;
  background: #fff; border-radius: 10px;
  border: 1px solid #e5e9f0;
  margin-bottom: 14px;
}
.fb-field { display: flex; flex-direction: column; }
.fb-field--grow { flex: 1; min-width: 200px; }
.fb-input {
  padding: 8px 12px; border: 1.5px solid #d8dde6;
  border-radius: 8px; font-size: 13px; outline: none;
  background: #fafbfc; color: #222;
  transition: border-color .15s;
}
.fb-input:focus { border-color: #5A9AC5; }
.fb-input--sm { min-width: 110px; }
.fb-toggle {
  display: flex; align-items: center; gap: 6px;
  font-size: 12px; font-weight: 600; color: #555;
  cursor: pointer;
}
.fb-btn {
  padding: 8px 16px; border-radius: 8px;
  font-size: 13px; font-weight: 600; cursor: pointer;
  border: none; transition: all .15s;
  white-space: nowrap;
}
.fb-btn--ghost   { background: #f0f0f0; color: #555; }
.fb-btn--ghost:hover { background: #e0e0e0; }
.fb-btn--primary { background: #5A9AC5; color: #fff; }
.fb-btn--primary:hover { background: #4a82b0; }
.fb-btn--create  { background: #2E7D72; color: #fff; }
.fb-btn--create:hover { background: #256660; }
</style>
