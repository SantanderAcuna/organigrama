<script setup lang="ts">
// ─────────────────────────────────────────────────────────────
// components/EntityForm.vue
// Modal form for Create / Edit an OrganigramaEntity
// ─────────────────────────────────────────────────────────────
import { ref, watch, computed } from 'vue'
import type { OrganigramaEntity, EntityType, CreateEntityPayload } from '@/types/organigrama'

// ── Props & Emits ────────────────────────────────────────────
const props = defineProps<{
  modelValue: boolean          // v-model: show/hide
  entity?: OrganigramaEntity | null  // null = create mode
  entityTypes: EntityType[]
  parentOptions: OrganigramaEntity[] // flat list for parent selector
}>()

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  'submit': [payload: CreateEntityPayload, id?: number]
}>()

// ── Local form state ─────────────────────────────────────────
const DEFAULT_FORM = (): CreateEntityPayload => ({
  name:        '',
  type:        'secretaria',
  parent_id:   null,
  order:       0,
  active:      true,
  description: null,
})

const form   = ref<CreateEntityPayload>(DEFAULT_FORM())
const errors = ref<Partial<Record<keyof CreateEntityPayload, string>>>({})

const isEdit = computed(() => !!props.entity)
const title  = computed(() => isEdit.value ? 'Editar Entidad' : 'Nueva Entidad')

// Sync form when entity changes
watch(
  () => props.entity,
  (e) => {
    if (e) {
      form.value = {
        name:        e.name,
        type:        e.type,
        parent_id:   e.parent_id,
        order:       e.order,
        active:      e.active,
        description: e.description,
      }
    } else {
      form.value = DEFAULT_FORM()
    }
    errors.value = {}
  },
  { immediate: true },
)

// ── Validation ───────────────────────────────────────────────
function validate(): boolean {
  errors.value = {}
  if (!form.value.name.trim())  errors.value.name = 'El nombre es requerido.'
  if (!form.value.type)         errors.value.type = 'El tipo es requerido.'
  return Object.keys(errors.value).length === 0
}

// ── Submit ───────────────────────────────────────────────────
function handleSubmit() {
  if (!validate()) return
  emit('submit', { ...form.value }, props.entity?.id)
  close()
}

function close() {
  emit('update:modelValue', false)
}
</script>

<template>
  <!-- Backdrop -->
  <Teleport to="body">
    <Transition name="modal">
      <div v-if="modelValue" class="ef-backdrop" @click.self="close">
        <div class="ef-modal" role="dialog" aria-modal="true" :aria-label="title">

          <!-- Header -->
          <div class="ef-header">
            <h2 class="ef-title">{{ title }}</h2>
            <button class="ef-close" @click="close" aria-label="Cerrar">✕</button>
          </div>

          <!-- Body -->
          <div class="ef-body">
            <form @submit.prevent="handleSubmit" novalidate>

              <!-- Name -->
              <div class="ef-field">
                <label class="ef-label" for="ef-name">Nombre *</label>
                <input
                  id="ef-name"
                  v-model.trim="form.name"
                  class="ef-input"
                  :class="{ 'ef-input--error': errors.name }"
                  type="text"
                  placeholder="Ej: Secretaría de Educación"
                  maxlength="255"
                />
                <span v-if="errors.name" class="ef-error">{{ errors.name }}</span>
              </div>

              <!-- Type -->
              <div class="ef-field">
                <label class="ef-label" for="ef-type">Tipo *</label>
                <select
                  id="ef-type"
                  v-model="form.type"
                  class="ef-input"
                  :class="{ 'ef-input--error': errors.type }"
                >
                  <option value="" disabled>Seleccione un tipo...</option>
                  <option
                    v-for="t in entityTypes"
                    :key="t.value"
                    :value="t.value"
                  >
                    {{ t.label }}
                  </option>
                </select>
                <!-- Color preview -->
                <div
                  v-if="form.type"
                  class="ef-color-preview"
                  :style="{
                    background: entityTypes.find(t => t.value === form.type)?.color ?? '#ccc'
                  }"
                ></div>
                <span v-if="errors.type" class="ef-error">{{ errors.type }}</span>
              </div>

              <!-- Parent -->
              <div class="ef-field">
                <label class="ef-label" for="ef-parent">Entidad superior</label>
                <select id="ef-parent" v-model="form.parent_id" class="ef-input">
                  <option :value="null">— Sin superior (raíz) —</option>
                  <option
                    v-for="p in parentOptions.filter(p => p.id !== entity?.id)"
                    :key="p.id"
                    :value="p.id"
                  >
                    {{ p.name }}
                  </option>
                </select>
              </div>

              <!-- Order -->
              <div class="ef-field ef-field--half">
                <label class="ef-label" for="ef-order">Orden</label>
                <input
                  id="ef-order"
                  v-model.number="form.order"
                  class="ef-input"
                  type="number"
                  min="0"
                  max="9999"
                />
              </div>

              <!-- Active -->
              <div class="ef-field ef-field--half">
                <label class="ef-label">Estado</label>
                <label class="ef-toggle">
                  <input v-model="form.active" type="checkbox" />
                  <span class="ef-toggle-track">
                    <span class="ef-toggle-thumb"></span>
                  </span>
                  <span>{{ form.active ? 'Activo' : 'Inactivo' }}</span>
                </label>
              </div>

              <!-- Description -->
              <div class="ef-field">
                <label class="ef-label" for="ef-desc">Descripción</label>
                <textarea
                  id="ef-desc"
                  v-model="form.description"
                  class="ef-input ef-textarea"
                  placeholder="Opcional…"
                  rows="3"
                  maxlength="1000"
                ></textarea>
              </div>

              <!-- Actions -->
              <div class="ef-actions">
                <button type="button" class="ef-btn ef-btn--ghost" @click="close">
                  Cancelar
                </button>
                <button type="submit" class="ef-btn ef-btn--primary">
                  {{ isEdit ? 'Guardar cambios' : 'Crear entidad' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.ef-backdrop {
  position: fixed; inset: 0;
  background: rgba(0,0,0,.45);
  display: flex; align-items: center; justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(2px);
}
.ef-modal {
  background: #fff;
  border-radius: 12px;
  width: min(540px, 95vw);
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0,0,0,.2);
}
.ef-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 18px 22px 14px;
  border-bottom: 1px solid #eee;
  position: sticky; top: 0; background: #fff; z-index: 1;
}
.ef-title { font-size: 17px; font-weight: 700; color: #1a1a2e; }
.ef-close {
  background: none; border: none; cursor: pointer;
  font-size: 18px; color: #888; line-height: 1;
}
.ef-close:hover { color: #333; }
.ef-body { padding: 20px 22px 22px; }
.ef-field {
  margin-bottom: 16px;
  position: relative;
}
.ef-field--half { display: inline-block; width: 48%; }
.ef-field--half + .ef-field--half { margin-left: 4%; }
.ef-label {
  display: block; font-size: 12px; font-weight: 600;
  color: #555; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .4px;
}
.ef-input {
  width: 100%; padding: 9px 12px;
  border: 1.5px solid #d8dde6;
  border-radius: 8px; font-size: 13px; color: #222;
  background: #fafbfc;
  transition: border-color .15s;
  outline: none;
}
.ef-input:focus { border-color: #5A9AC5; background: #fff; }
.ef-input--error { border-color: #e53935; }
.ef-textarea { resize: vertical; font-family: inherit; }
.ef-error { font-size: 11px; color: #e53935; margin-top: 3px; display: block; }
.ef-color-preview {
  width: 28px; height: 14px; border-radius: 4px;
  position: absolute; right: 12px; top: 32px;
}
/* Toggle */
.ef-toggle { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; }
.ef-toggle input { display: none; }
.ef-toggle-track {
  width: 38px; height: 20px; background: #ccc;
  border-radius: 20px; position: relative; transition: background .2s;
}
.ef-toggle input:checked ~ .ef-toggle-track { background: #5A9AC5; }
.ef-toggle-thumb {
  position: absolute; left: 2px; top: 2px;
  width: 16px; height: 16px; background: #fff;
  border-radius: 50%; transition: left .2s;
}
.ef-toggle input:checked ~ .ef-toggle-track .ef-toggle-thumb { left: 20px; }
/* Buttons */
.ef-actions {
  display: flex; justify-content: flex-end; gap: 10px; margin-top: 24px;
}
.ef-btn {
  padding: 9px 20px; border-radius: 8px; font-size: 13px;
  font-weight: 600; cursor: pointer; border: none; transition: all .15s;
}
.ef-btn--ghost {
  background: #f0f0f0; color: #555;
}
.ef-btn--ghost:hover { background: #e0e0e0; }
.ef-btn--primary {
  background: #5A9AC5; color: #fff;
}
.ef-btn--primary:hover { background: #4a82b0; }
/* Transition */
.modal-enter-active, .modal-leave-active { transition: opacity .2s; }
.modal-enter-active .ef-modal, .modal-leave-active .ef-modal { transition: transform .2s; }
.modal-enter-from, .modal-leave-to { opacity: 0; }
.modal-enter-from .ef-modal, .modal-leave-to .ef-modal { transform: translateY(-16px) scale(.97); }
</style>
