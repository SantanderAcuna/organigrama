<script setup lang="ts">
// ─────────────────────────────────────────────────────────────
// components/EntityTable.vue
// ─────────────────────────────────────────────────────────────
import type { OrganigramaEntity } from '@/types/organigrama'

const props = defineProps<{
  entities: OrganigramaEntity[]
  loading: boolean
  total: number
  currentPage: number
  lastPage: number
}>()

const emit = defineEmits<{
  edit:   [entity: OrganigramaEntity]
  delete: [entity: OrganigramaEntity]
  page:   [page: number]
}>()
</script>

<template>
  <div class="et-wrapper">
    <!-- Table -->
    <div class="et-table-wrap">
      <table class="et-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Superior</th>
            <th class="et-center">Orden</th>
            <th class="et-center">Estado</th>
            <th class="et-center">Hijos</th>
            <th class="et-center">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <!-- Loading skeleton -->
          <template v-if="loading">
            <tr v-for="n in 8" :key="n" class="et-skeleton">
              <td colspan="8"><div class="et-skel-bar"></div></td>
            </tr>
          </template>

          <!-- Empty -->
          <tr v-else-if="!entities.length">
            <td colspan="8" class="et-empty">
              <span>😶‍🌫️ No hay entidades para mostrar</span>
            </td>
          </tr>

          <!-- Rows -->
          <tr
            v-else
            v-for="entity in entities"
            :key="entity.id"
            class="et-row"
          >
            <td class="et-id">{{ entity.id }}</td>

            <td class="et-name">{{ entity.name }}</td>

            <td>
              <span
                class="et-badge"
                :style="{ background: entity.type_color }"
              >
                {{ entity.type_label }}
              </span>
            </td>

            <td class="et-parent">{{ entity.parent_name ?? '—' }}</td>

            <td class="et-center">{{ entity.order }}</td>

            <td class="et-center">
              <span :class="['et-status', entity.active ? 'et-status--on' : 'et-status--off']">
                {{ entity.active ? 'Activo' : 'Inactivo' }}
              </span>
            </td>

            <td class="et-center">{{ entity.children_count ?? 0 }}</td>

            <td class="et-center et-actions-cell">
              <button
                class="et-btn et-btn--edit"
                title="Editar"
                @click="emit('edit', entity)"
              >✏️</button>
              <button
                class="et-btn et-btn--delete"
                title="Eliminar"
                @click="emit('delete', entity)"
              >🗑️</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div v-if="lastPage > 1" class="et-pagination">
      <span class="et-total">Total: {{ total }}</span>
      <div class="et-pages">
        <button
          class="et-page-btn"
          :disabled="currentPage === 1"
          @click="emit('page', currentPage - 1)"
        >‹</button>

        <button
          v-for="p in lastPage"
          :key="p"
          :class="['et-page-btn', p === currentPage ? 'et-page-btn--active' : '']"
          @click="emit('page', p)"
        >{{ p }}</button>

        <button
          class="et-page-btn"
          :disabled="currentPage === lastPage"
          @click="emit('page', currentPage + 1)"
        >›</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.et-wrapper { display: flex; flex-direction: column; gap: 12px; }

.et-table-wrap { overflow-x: auto; border-radius: 10px; border: 1px solid #e5e9f0; }

.et-table {
  width: 100%; border-collapse: collapse;
  font-size: 13px; color: #333;
}

.et-table thead { background: #f1f5fa; }
.et-table th {
  padding: 11px 14px; text-align: left;
  font-size: 11px; font-weight: 700;
  text-transform: uppercase; letter-spacing: .5px; color: #667;
  white-space: nowrap;
  border-bottom: 2px solid #e0e6ee;
}

.et-row { border-bottom: 1px solid #f0f2f7; transition: background .12s; }
.et-row:hover { background: #f7faff; }
.et-row:last-child { border-bottom: none; }

.et-table td { padding: 10px 14px; vertical-align: middle; }

.et-id     { color: #aaa; font-size: 11px; width: 40px; }
.et-name   { font-weight: 600; max-width: 240px; }
.et-parent { color: #666; font-size: 12px; }
.et-center { text-align: center; }

.et-badge {
  display: inline-block; padding: 3px 8px;
  border-radius: 20px; font-size: 10.5px;
  font-weight: 700; color: #fff;
  white-space: nowrap;
}

.et-status {
  display: inline-block; padding: 3px 8px;
  border-radius: 20px; font-size: 10.5px; font-weight: 700;
}
.et-status--on  { background: #e8f5e9; color: #388e3c; }
.et-status--off { background: #fce4ec; color: #c62828; }

.et-actions-cell { display: flex; justify-content: center; gap: 6px; }
.et-btn {
  background: none; border: none; cursor: pointer;
  font-size: 15px; padding: 4px 6px; border-radius: 6px;
  transition: background .12s;
}
.et-btn--edit:hover   { background: #e3f2fd; }
.et-btn--delete:hover { background: #ffebee; }

/* Skeleton */
.et-skeleton td { padding: 8px 14px; }
.et-skel-bar {
  height: 20px; background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
  background-size: 200% 100%; border-radius: 4px;
  animation: shimmer 1.2s infinite;
}
@keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }

.et-empty { text-align: center; padding: 40px !important; color: #999; font-size: 15px; }

/* Pagination */
.et-pagination {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 4px;
}
.et-total { font-size: 12px; color: #888; }
.et-pages { display: flex; gap: 4px; }
.et-page-btn {
  width: 30px; height: 30px; border-radius: 7px;
  border: 1.5px solid #dde3ee; background: #fff;
  font-size: 12px; font-weight: 600; cursor: pointer;
  transition: all .12s; color: #445;
}
.et-page-btn:hover:not(:disabled) { border-color: #5A9AC5; color: #5A9AC5; }
.et-page-btn--active { background: #5A9AC5; border-color: #5A9AC5; color: #fff; }
.et-page-btn:disabled { opacity: .4; cursor: not-allowed; }
</style>
