<script setup lang="ts">
// components/ConfirmDialog.vue
defineProps<{
  modelValue: boolean
  title?: string
  message?: string
  confirmLabel?: string
  danger?: boolean
}>()

const emit = defineEmits<{
  'update:modelValue': [v: boolean]
  confirm: []
}>()

const cancel  = () => emit('update:modelValue', false)
const confirm = () => { emit('confirm'); emit('update:modelValue', false) }
</script>

<template>
  <Teleport to="body">
    <Transition name="modal">
      <div v-if="modelValue" class="cd-backdrop" @click.self="cancel">
        <div class="cd-modal">
          <div class="cd-icon">{{ danger ? '⚠️' : '❓' }}</div>
          <h3 class="cd-title">{{ title ?? 'Confirmar acción' }}</h3>
          <p class="cd-msg">{{ message ?? '¿Estás seguro de continuar?' }}</p>
          <div class="cd-actions">
            <button class="cd-btn cd-btn--ghost" @click="cancel">Cancelar</button>
            <button
              :class="['cd-btn', danger ? 'cd-btn--danger' : 'cd-btn--primary']"
              @click="confirm"
            >
              {{ confirmLabel ?? 'Confirmar' }}
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<style scoped>
.cd-backdrop {
  position: fixed; inset: 0;
  background: rgba(0,0,0,.45);
  display: flex; align-items: center; justify-content: center;
  z-index: 1100; backdrop-filter: blur(2px);
}
.cd-modal {
  background: #fff; border-radius: 12px;
  padding: 30px 28px; width: min(380px, 92vw);
  text-align: center;
  box-shadow: 0 16px 48px rgba(0,0,0,.2);
}
.cd-icon { font-size: 36px; margin-bottom: 10px; }
.cd-title { font-size: 16px; font-weight: 700; margin-bottom: 8px; color: #1a1a2e; }
.cd-msg   { font-size: 13px; color: #666; margin-bottom: 22px; line-height: 1.5; }
.cd-actions { display: flex; gap: 10px; justify-content: center; }
.cd-btn {
  padding: 9px 22px; border-radius: 8px;
  font-size: 13px; font-weight: 600;
  border: none; cursor: pointer; transition: all .15s;
}
.cd-btn--ghost   { background: #f0f0f0; color: #555; }
.cd-btn--ghost:hover { background: #e0e0e0; }
.cd-btn--primary { background: #5A9AC5; color: #fff; }
.cd-btn--danger  { background: #e53935; color: #fff; }
.cd-btn--danger:hover { background: #c62828; }
.modal-enter-active, .modal-leave-active { transition: opacity .2s; }
.modal-enter-from, .modal-leave-to { opacity: 0; }
</style>
