// ─────────────────────────────────────────────────────────────
// router/index.ts
// ─────────────────────────────────────────────────────────────
import { createRouter, createWebHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/organigrama',
  },
  {
    path: '/organigrama',
    name: 'organigrama',
    component: () => import('@/views/OrganigramaView.vue'),
    meta: { title: 'Organigrama — Medellín' },
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

// Dynamic page title
router.afterEach((to) => {
  document.title = (to.meta.title as string) ?? 'Organigrama'
})

export default router
