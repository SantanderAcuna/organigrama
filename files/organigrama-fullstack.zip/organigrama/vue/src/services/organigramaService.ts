// ─────────────────────────────────────────────────────────────
// services/organigramaService.ts
// ─────────────────────────────────────────────────────────────
import api from './api'
import type {
  CreateEntityPayload,
  EntityFilters,
  MessageResponse,
  OrganigramaEntity,
  PaginatedResponse,
  ReorderItem,
  SingleResponse,
  TypesResponse,
  UpdateEntityPayload,
} from '@/types/organigrama'

const BASE = '/organigrama'

export const organigramaService = {

  // List (paginated) with optional filters
  list(filters: Partial<EntityFilters> = {}) {
    return api.get<PaginatedResponse<OrganigramaEntity>>(BASE, { params: filters })
  },

  // Full nested tree
  tree() {
    return api.get<{ data: OrganigramaEntity[] }>(BASE, { params: { tree: true } })
  },

  // Single entity (with children)
  get(id: number) {
    return api.get<SingleResponse<OrganigramaEntity>>(`${BASE}/${id}`)
  },

  // Create
  create(payload: CreateEntityPayload) {
    return api.post<SingleResponse<OrganigramaEntity>>(BASE, payload)
  },

  // Update (full replace)
  update(id: number, payload: UpdateEntityPayload) {
    return api.put<SingleResponse<OrganigramaEntity>>(`${BASE}/${id}`, payload)
  },

  // Partial update
  patch(id: number, payload: UpdateEntityPayload) {
    return api.patch<SingleResponse<OrganigramaEntity>>(`${BASE}/${id}`, payload)
  },

  // Delete
  remove(id: number) {
    return api.delete<MessageResponse>(`${BASE}/${id}`)
  },

  // Available types + colors
  types() {
    return api.get<TypesResponse>(`${BASE}/types`)
  },

  // Batch reorder
  reorder(items: ReorderItem[]) {
    return api.patch<MessageResponse>(`${BASE}/reorder`, { items })
  },
}
