// ─────────────────────────────────────────────────────────────
// services/api.ts  – Axios instance + interceptors
// ─────────────────────────────────────────────────────────────
import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:8000/api',
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
  withCredentials: true, // for Sanctum / CSRF cookies if needed
})

// Request interceptor: attach Bearer token if stored
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('api_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Response interceptor: normalize errors
api.interceptors.response.use(
  (res) => res,
  (error) => {
    const msg: string =
      error.response?.data?.message ??
      error.response?.data?.error ??
      error.message ??
      'Error desconocido'
    return Promise.reject(new Error(msg))
  },
)

export default api
